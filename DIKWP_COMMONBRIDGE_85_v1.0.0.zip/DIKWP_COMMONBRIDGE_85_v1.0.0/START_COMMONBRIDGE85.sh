#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 start_showcase.py
